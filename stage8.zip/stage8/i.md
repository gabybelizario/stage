const database = require("./database/sqlite");
database();
const usersRouter = require("./users.routes");